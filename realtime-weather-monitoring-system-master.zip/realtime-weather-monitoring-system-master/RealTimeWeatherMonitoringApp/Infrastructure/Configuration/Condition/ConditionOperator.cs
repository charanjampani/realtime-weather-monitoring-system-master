namespace RealTimeWeatherMonitoringApp.Infrastructure.Configuration.Condition;

public enum ConditionOperator
{
    GreaterThan = 0,
    LessThan = 1
}