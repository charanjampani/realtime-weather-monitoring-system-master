namespace RealTimeWeatherMonitoringApp.Infrastructure.Configuration.Condition;

public enum ConditionType
{
    Temperature = 0,
    Humidity = 1
}